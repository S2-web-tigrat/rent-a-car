<?php
  $conn = mysqli_connect("localhost", "root", "", "rent-car");